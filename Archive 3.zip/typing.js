
  document.addEventListener("DOMContentLoaded", function () {
    new Typed("#typed", {
      strings: ["Frontend Developer", "Creative Developer", "UX/UI Designer", "Football Freak"],
      typeSpeed: 120,  // Speed for typing
      backSpeed:70,   // Speed for deleting
      backDelay: 1500, // Delay before starting to delete
      loop: true       // Loop through the words
    });
  });

